### TODO
- Search filter
- Text Formatting
- Date-Time Format customization
- Themes
- UNDO after delete
- delete animation/smooth scrolling
- // "options_page":"options/options.html"
- Tags
