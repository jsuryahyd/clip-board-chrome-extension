### TODO
- Search filter
- Text Formatting on a button click. Adding a diff input area if required by user to allow formatted text.
- Date-Time Format customization
- Themes
- UNDO after delete
- delete animation/smooth scrolling
- // "options_page":"options/options.html"
- Tags

